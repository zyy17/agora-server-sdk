Incomplete SDK fixture: no libraries or headers.
